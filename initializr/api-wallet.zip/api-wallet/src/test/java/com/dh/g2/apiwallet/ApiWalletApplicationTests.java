package com.dh.g2.apiwallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
